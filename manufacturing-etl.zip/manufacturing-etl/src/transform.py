import pandas as pd
import numpy as np
import hashlib

def clean_sensor_data(df):
    """
    Nettoie les données des capteurs selon Task 2.1
    
    Args:
        df (pandas.DataFrame): DataFrame des données capteurs
        
    Returns:
        pandas.DataFrame: DataFrame nettoyé avec flag data_quality
    """
    if df.empty:
        return df
    
    print(f"🧹 Nettoyage des données capteurs: {len(df)} lignes")
    df_clean = df.copy()
    
    # 1. Remplacer les codes d'erreur par NaN
    error_codes = [-999, -1, 'NULL', 'null', 'None', 'none']
    
    # Colonnes à nettoyer
    sensor_cols = ['temperature', 'pressure', 'vibration']
    available_cols = [col for col in sensor_cols if col in df_clean.columns]
    
    for col in available_cols:
        initial_nulls = df_clean[col].isna().sum()
        
        # Convertir en numérique
        df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
        
        # Remplacer les codes d'erreur
        for error in error_codes:
            if isinstance(error, (int, float)):
                df_clean.loc[df_clean[col] == error, col] = np.nan
        
        # Remplacer les NULL strings
        df_clean[col] = df_clean[col].replace('NULL', np.nan)
        df_clean[col] = df_clean[col].replace('null', np.nan)
        
        new_nulls = df_clean[col].isna().sum()
        if new_nulls > initial_nulls:
            print(f"   {col}: {new_nulls - initial_nulls} valeurs d'erreur → NaN")
    
    # 2. Valider les plages
    ranges = {
        'temperature': (0, 150),   # 0°C to 150°C
        'pressure': (0, 10),       # 0 to 10 bar
        'vibration': (0, 100)      # 0 to 100 mm/s
    }
    
    # Initialiser le flag de qualité
    df_clean['data_quality'] = 'good'
    
    for col, (min_val, max_val) in ranges.items():
        if col in df_clean.columns:
            # Identifier les valeurs hors plage
            invalid_mask = (df_clean[col] < min_val) | (df_clean[col] > max_val)
            invalid_mask = invalid_mask & df_clean[col].notna()  # Ignorer les NaN
            
            invalid_count = invalid_mask.sum()
            if invalid_count > 0:
                # Marquer comme invalide
                df_clean.loc[invalid_mask, 'data_quality'] = 'invalid'
                # Remplacer par NaN
                df_clean.loc[invalid_mask, col] = np.nan
                print(f"   {col}: {invalid_count} valeurs hors plage [{min_val}, {max_val}] → NaN")
    
    # 3. Forward fill pour les valeurs manquantes
    for col in available_cols:
        if col in df_clean.columns:
            # Compter les NaN avant forward fill
            na_before = df_clean[col].isna()
            
            # Sauvegarder l'état avant forward fill
            original_na = na_before.copy()
            
            # Forward fill
            df_clean[col] = df_clean[col].ffill()
            
            # Identifier les valeurs estimées (NaN avant, pas NaN après)
            estimated_mask = df_clean[col].notna() & original_na
            estimated_count = estimated_mask.sum()
            
            if estimated_count > 0:
                df_clean.loc[estimated_mask, 'data_quality'] = 'estimated'
                print(f"   {col}: {estimated_count} valeurs estimées (forward fill)")
    
    # Statistiques finales
    quality_dist = df_clean['data_quality'].value_counts()
    print(f"📊 Distribution data_quality: {dict(quality_dist)}")
    
    return df_clean

def standardize_data(df):
    """
    Standardise les données selon Task 2.2
    
    Args:
        df (pandas.DataFrame): DataFrame à standardiser
        
    Returns:
        pandas.DataFrame: DataFrame standardisé avec record_id
    """
    if df.empty:
        return df
    
    print(f"📏 Standardisation des données: {len(df)} lignes")
    df_std = df.copy()
    
    # 1. Convertir tous les timestamps en datetime
    timestamp_cols = [col for col in df_std.columns 
                     if 'time' in col.lower() or 'date' in col.lower()]
    
    for col in timestamp_cols:
        try:
            df_std[col] = pd.to_datetime(df_std[col])
            print(f"   ✅ '{col}' converti en datetime")
        except:
            print(f"   ⚠️ Impossible de convertir '{col}' en datetime")
    
    # 2. Minuscules pour les noms de machine/sensor
    text_cols = [col for col in df_std.columns 
                if any(keyword in col.lower() for keyword in 
                      ['machine', 'sensor', 'line', 'id', 'name', 'type', 'result'])]
    
    for col in text_cols:
        if df_std[col].dtype == 'object':
            df_std[col] = df_std[col].astype(str).str.lower()
    
    print(f"   ✅ Textes convertis en minuscules")
    
    # 3. Nettoyer les noms de colonnes
    original_cols = list(df_std.columns)
    df_std.columns = [col.strip().replace(' ', '_').lower() for col in df_std.columns]
    
    # Vérifier les changements
    changed = [(orig, new) for orig, new in zip(original_cols, df_std.columns) if orig != new]
    if changed:
        print(f"   🔄 Colonnes renommées:")
        for orig, new in changed:
            print(f"      '{orig}' → '{new}'")
    
    # 4. Créer un unique record_id pour chaque ligne
    def generate_record_id(row):
        try:
            # Utiliser plusieurs colonnes pour créer un hash unique
            parts = []
            
            # Ajouter timestamp si disponible
            if 'timestamp' in row.index and pd.notna(row['timestamp']):
                parts.append(str(row['timestamp']))
            
            # Ajouter machine_id si disponible
            if 'machine_id' in row.index and pd.notna(row['machine_id']):
                parts.append(str(row['machine_id']))
            
            # Ajouter line_id si disponible
            if 'line_id' in row.index and pd.notna(row['line_id']):
                parts.append(str(row['line_id']))
            
            # Si aucune colonne disponible, utiliser l'index
            if not parts:
                parts.append(str(row.name))
            
            # Créer une chaîne unique
            unique_string = '_'.join(parts)
            
            # Générer un hash MD5 et prendre les 12 premiers caractères
            return hashlib.md5(unique_string.encode()).hexdigest()[:12]
            
        except Exception as e:
            # Fallback: utiliser l'index
            return f"row_{row.name:08d}"
    
    df_std['record_id'] = df_std.apply(generate_record_id, axis=1)
    
    # Vérifier l'unicité des record_id
    unique_ids = df_std['record_id'].nunique()
    if unique_ids == len(df_std):
        print(f"   ✅ {unique_ids} IDs uniques créés")
    else:
        print(f"   ⚠️ {len(df_std) - unique_ids} IDs en double détectés")
    
    print(f"   📋 {len(df_std.columns)} colonnes finales")
    return df_std

def join_sensor_quality(sensor_df, quality_df):
    """
    Joint les données capteurs et qualité selon Task 2.3
    
    Args:
        sensor_df (pandas.DataFrame): Données capteurs
        quality_df (pandas.DataFrame): Données qualité
        
    Returns:
        pandas.DataFrame: DataFrame joint avec quality_status
    """
    print(f"🔗 Jointure capteurs/qualité")
    print(f"   Capteurs: {len(sensor_df)} lignes")
    print(f"   Qualité: {len(quality_df)} lignes")
    
    if sensor_df.empty:
        print("⚠️ DataFrame capteurs vide")
        return pd.DataFrame()
    
    # Préparer les DataFrames
    sensor_prep = sensor_df.copy()
    quality_prep = quality_df.copy() if not quality_df.empty else pd.DataFrame()
    
    # Déterminer les colonnes de jointure
    join_on = []
    
    # Timestamp
    if 'timestamp' in sensor_prep.columns and 'timestamp' in quality_prep.columns:
        join_on.append('timestamp')
        # S'assurer que les timestamps sont compatibles
        sensor_prep['timestamp'] = pd.to_datetime(sensor_prep['timestamp'])
        quality_prep['timestamp'] = pd.to_datetime(quality_prep['timestamp'])
    
    # Machine ID
    if 'machine_id' in sensor_prep.columns and 'machine_id' in quality_prep.columns:
        join_on.append('machine_id')
    
    # Line ID (optionnel)
    if ('line_id' in sensor_prep.columns and 'line_id' in quality_prep.columns and
        'line_id' not in join_on):
        join_on.append('line_id')
    
    if not join_on:
        print("❌ Aucune colonne commune pour la jointure")
        sensor_prep['quality_status'] = 'not_checked'
        return sensor_prep
    
    print(f"   Jointure sur: {join_on}")
    
    if quality_prep.empty:
        print("⚠️ DataFrame qualité vide")
        sensor_prep['quality_status'] = 'not_checked'
        return sensor_prep
    
    # Effectuer la jointure LEFT
    try:
        merged_df = pd.merge(
            sensor_prep,
            quality_prep,
            on=join_on,
            how='left',  # LEFT JOIN pour garder toutes les données capteurs
            suffixes=('', '_quality')  # Pas de suffixe pour sensor, '_quality' pour quality
        )
        
        print(f"   ✅ Jointure réussie: {len(merged_df)} lignes")
        
        # 5. Ajouter la colonne quality_status
        if 'result' in merged_df.columns:
            # Normaliser les résultats
            merged_df['result'] = merged_df['result'].astype(str).str.lower().str.strip()
            
            # Définir quality_status
            def determine_quality_status(result):
                if pd.isna(result) or result in ['', 'nan', 'none']:
                    return 'not_checked'
                elif result == 'pass':
                    return 'passed'
                elif result == 'fail':
                    return 'failed'
                else:
                    # Pour d'autres valeurs, essayer de deviner
                    if 'pass' in result:
                        return 'passed'
                    elif 'fail' in result:
                        return 'failed'
                    else:
                        return 'unknown'
            
            merged_df['quality_status'] = merged_df['result'].apply(determine_quality_status)
        else:
            merged_df['quality_status'] = 'not_checked'
        
        # Statistiques sur les jointures
        matched = merged_df['quality_status'] != 'not_checked'
        print(f"   📊 {matched.sum()} lignes avec données qualité correspondantes")
        print(f"   📊 {(~matched).sum()} lignes sans données qualité")
        
        return merged_df
        
    except Exception as e:
        print(f"❌ Erreur lors de la jointure: {e}")
        # Fallback: retourner sensor_df avec quality_status par défaut
        sensor_prep['quality_status'] = 'not_checked'
        return sensor_prep

def calculate_hourly_summaries(df):
    """
    Calcule les agrégations horaires selon Task 2.4
    
    Args:
        df (pandas.DataFrame): Données jointes
        
    Returns:
        pandas.DataFrame: Agrégations horaires
    """
    if df.empty:
        print("⚠️ DataFrame vide")
        return pd.DataFrame()
    
    print(f"⏰ Calcul des agrégations horaires: {len(df)} lignes")
    
    # Vérifier les colonnes nécessaires
    if 'timestamp' not in df.columns:
        print("❌ Colonne 'timestamp' manquante")
        return pd.DataFrame()
    
    # Créer une copie pour éviter les modifications
    df_agg = df.copy()
    
    # Convertir timestamp en datetime
    try:
        df_agg['timestamp'] = pd.to_datetime(df_agg['timestamp'])
    except:
        print("❌ Impossible de convertir 'timestamp' en datetime")
        return pd.DataFrame()
    
    # Créer la colonne 'hour' (arrondie à l'heure)
    df_agg['hour'] = df_agg['timestamp'].dt.floor('h')
    
    # Déterminer les colonnes de groupement
    group_cols = ['hour']
    
    if 'line_id' in df_agg.columns:
        group_cols.append('line_id')
    
    if 'machine_id' in df_agg.columns:
        group_cols.append('machine_id')
    
    print(f"   Groupement par: {group_cols}")
    
    # Vérifier qu'on a au moins hour + une autre colonne
    if len(group_cols) < 2:
        print("❌ Pas assez de colonnes pour le groupement")
        return pd.DataFrame()
    
    # Calculer les agrégations
    summaries = []
    
    for (group_key), group in df_agg.groupby(group_cols):
        summary = {}
        
        # Ajouter les valeurs de groupement
        if len(group_cols) == 2:
            hour_val, line_val = group_key
            summary['hour'] = hour_val
            summary['line_id'] = line_val
            machine_id = group['machine_id'].iloc[0] if 'machine_id' in group.columns else 'unknown'
            summary['machine_id'] = machine_id
            
        elif len(group_cols) == 3:
            hour_val, line_val, machine_val = group_key
            summary['hour'] = hour_val
            summary['line_id'] = line_val
            summary['machine_id'] = machine_val
        
        # 6. Calculer pour chaque sensor: avg, min, max, std
        sensor_cols = ['temperature', 'pressure', 'vibration']
        
        for sensor in sensor_cols:
            if sensor in group.columns:
                # Convertir en numérique
                sensor_data = pd.to_numeric(group[sensor], errors='coerce')
                
                # Calculer les statistiques
                summary[f'avg_{sensor}'] = sensor_data.mean()
                summary[f'min_{sensor}'] = sensor_data.min()
                summary[f'max_{sensor}'] = sensor_data.max()
                summary[f'std_{sensor}'] = sensor_data.std()
        
        # 7. Compter total quality checks et defects
        if 'quality_status' in group.columns:
            # Total checks: lignes avec quality_status != 'not_checked'
            total_checks = (group['quality_status'] != 'not_checked').sum()
            defect_count = (group['quality_status'] == 'failed').sum()
        else:
            total_checks = 0
            defect_count = 0
        
        summary['total_checks'] = total_checks
        summary['defect_count'] = defect_count
        
        # 8. Calculer defect rate
        if total_checks > 0:
            summary['defect_rate'] = (defect_count / total_checks) * 100
        else:
            summary['defect_rate'] = 0.0
        
        summaries.append(summary)
    
    # Créer le DataFrame final
    if summaries:
        result_df = pd.DataFrame(summaries)
        
        # Réorganiser les colonnes pour plus de clarté
        col_order = ['hour', 'line_id', 'machine_id']
        sensor_stats = []
        
        for sensor in ['temperature', 'pressure', 'vibration']:
            for stat in ['avg', 'min', 'max', 'std']:
                col_name = f'{stat}_{sensor}'
                if col_name in result_df.columns:
                    sensor_stats.append(col_name)
        
        other_cols = ['total_checks', 'defect_count', 'defect_rate']
        
        final_cols = col_order + sensor_stats + other_cols
        available_cols = [col for col in final_cols if col in result_df.columns]
        
        result_df = result_df[available_cols]
        
        print(f"✅ {len(result_df)} agrégations horaires calculées")
        print(f"   📋 Colonnes: {list(result_df.columns)}")
        
        return result_df
    else:
        print("❌ Aucune agrégation calculée")
        return pd.DataFrame()


# ============================================================================
# PARTIE TEST - S'exécute SEULEMENT si on lance transform.py directement
# ============================================================================
if __name__ == "__main__":
    print("=" * 70)
    print("TEST DES FONCTIONS DE TRANSFORMATION")
    print("=" * 70)
    
    # Créer des données de test
    print("\n📝 Création de données de test...")
    
    # Données capteurs
    sensor_data = pd.DataFrame({
        'Timestamp': pd.date_range('2024-01-01', periods=10, freq='h'),
        'Machine ID': ['M1', 'M2'] * 5,
        'Line ID': ['L1', 'L2'] * 5,
        'temperature': [25, 26, -999, 28, 29, 30, 200, 32, 33, 34],
        'pressure': [5.0, 5.1, 5.2, -1, 5.4, 5.5, 5.6, 15, 5.8, 5.9],
        'vibration': [10, 11, 12, 13, 14, 150, 16, 17, 18, 19]
    })
    
    # Données qualité
    quality_data = pd.DataFrame({
        'timestamp': pd.date_range('2024-01-01', periods=5, freq='2h'),
        'machine_id': ['M1', 'M2', 'M1', 'M2', 'M1'],
        'line_id': ['L1', 'L2', 'L1', 'L2', 'L1'],
        'result': ['pass', 'fail', 'pass', 'pass', 'fail']
    })
    
    print("✅ Données test créées")
    print(f"   Capteurs: {sensor_data.shape}")
    print(f"   Qualité: {quality_data.shape}")
    
    # Test 1: Nettoyage
    print(f"\n{'='*35} TEST 1: NETTOYAGE {'='*35}")
    cleaned = clean_sensor_data(sensor_data)
    print(f"\nRésultat nettoyage (premières 5 lignes):")
    print(cleaned.head())
    
    # Test 2: Standardisation
    print(f"\n{'='*35} TEST 2: STANDARDISATION {'='*35}")
    sensor_std = standardize_data(cleaned)
    quality_std = standardize_data(quality_data)
    print(f"\nCapteurs standardisés (colonnes):")
    print(list(sensor_std.columns))
    print(f"\nQualité standardisée (colonnes):")
    print(list(quality_std.columns))
    
    # Test 3: Jointure
    print(f"\n{'='*35} TEST 3: JOINTURE {'='*35}")
    joined = join_sensor_quality(sensor_std, quality_std)
    print(f"\nDonnées jointes (premières 5 lignes):")
    print(joined[['timestamp', 'machine_id', 'temperature', 'quality_status']].head())
    
    # Test 4: Agrégations horaires
    print(f"\n{'='*35} TEST 4: AGREGATIONS {'='*35}")
    hourly = calculate_hourly_summaries(joined)
    print(f"\nAgrégations horaires (toutes):")
    print(hourly)
    
    print(f"\n{'='*70}")
    print("🎉 TOUTES LES FONCTIONS FONCTIONNENT CORRECTEMENT!")
    print("=" * 70)
