import pandas as pd
import numpy as np  # AJOUTÉ
from datetime import datetime, timedelta
import os

def extract_sensor_data(file_path="data/raw/sensor_data.csv", days=7):
    """
    Extrait les données des capteurs selon Task 1.1
    Chemin par défaut: data/raw/sensor_data.csv
    
    Args:
        file_path (str): Chemin vers le fichier CSV des capteurs
        days (int): Nombre de jours à conserver (défaut: 7)
    
    Returns:
        pandas.DataFrame: DataFrame avec colonnes timestamp, machine_id, 
                         temperature, pressure, vibration
    """
    try:
        # Chemin absolu pour débogage
        abs_path = os.path.abspath(file_path)
        print(f"📁 Extraction capteurs depuis: {file_path}")
        print(f"   Chemin absolu: {abs_path}")
        
        # Vérifier si le fichier existe
        if not os.path.exists(file_path):
            print(f"❌ ERREUR: Fichier '{file_path}' non trouvé!")
            print(f"   Vérifiez que le fichier existe dans: data/raw/")
            print(f"   Vérifiez le dossier actuel: {os.getcwd()}")
            return pd.DataFrame()
        
        # Lire le fichier CSV
        df = pd.read_csv(file_path)
        print(f"✅ Fichier lu: {len(df)} lignes, {len(df.columns)} colonnes")
        
        # Afficher toutes les colonnes pour débogage
        print(f"📋 Colonnes originales ({len(df.columns)}):")
        for i, col in enumerate(df.columns):
            print(f"   {i+1:2d}. '{col}'")
        
        # Normaliser les noms de colonnes
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        
        # --- CHERCHER ET STANDARDISER LES COLONNES ---
        # 1. Timestamp (OBLIGATOIRE)
        timestamp_patterns = ['timestamp', 'time', 'datetime', 'date_time', 'time_stamp', 'date']
        timestamp_col = None
        for pattern in timestamp_patterns:
            matching_cols = [col for col in df.columns if pattern in col]
            if matching_cols:
                timestamp_col = matching_cols[0]
                break
        
        if timestamp_col is None:
            print("❌ ERREUR: Aucune colonne timestamp trouvée!")
            return pd.DataFrame()
        
        # 2. Machine ID (OBLIGATOIRE)
        machine_patterns = ['machine_id', 'machineid', 'machine', 'device_id', 'device', 'equipment_id']
        machine_col = None
        for pattern in machine_patterns:
            matching_cols = [col for col in df.columns if pattern in col]
            if matching_cols:
                machine_col = matching_cols[0]
                break
        
        if machine_col is None:
            print("❌ ERREUR: Aucune colonne machine_id trouvée!")
            return pd.DataFrame()
        
        # 3. Temperature (OPTIONNELLE mais recommandée)
        temp_patterns = ['temperature', 'temp', 'sensor_temp']
        temp_col = None
        for pattern in temp_patterns:
            matching_cols = [col for col in df.columns if pattern in col]
            if matching_cols:
                temp_col = matching_cols[0]
                break
        
        # 4. Pressure (OPTIONNELLE mais recommandée)
        pressure_patterns = ['pressure', 'press', 'sensor_pressure']
        pressure_col = None
        for pattern in pressure_patterns:
            matching_cols = [col for col in df.columns if pattern in col]
            if matching_cols:
                pressure_col = matching_cols[0]
                break
        
        # 5. Vibration (OPTIONNELLE mais recommandée)
        vibration_patterns = ['vibration', 'vibr', 'sensor_vibration']
        vibration_col = None
        for pattern in vibration_patterns:
            matching_cols = [col for col in df.columns if pattern in col]
            if matching_cols:
                vibration_col = matching_cols[0]
                break
        
        # Renommer les colonnes pour standardisation
        rename_dict = {}
        if timestamp_col != 'timestamp':
            rename_dict[timestamp_col] = 'timestamp'
        if machine_col != 'machine_id':
            rename_dict[machine_col] = 'machine_id'
        if temp_col and temp_col != 'temperature':
            rename_dict[temp_col] = 'temperature'
        if pressure_col and pressure_col != 'pressure':
            rename_dict[pressure_col] = 'pressure'
        if vibration_col and vibration_col != 'vibration':
            rename_dict[vibration_col] = 'vibration'
        
        if rename_dict:
            df = df.rename(columns=rename_dict)
            print(f"🔄 Colonnes renommées: {rename_dict}")
        
        # Convertir le timestamp en datetime
        try:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            print(f"✅ Timestamp converti en datetime")
        except Exception as e:
            print(f"❌ Erreur conversion timestamp: {e}")
            return pd.DataFrame()
        
        # Filtrer les données des 7 derniers jours
        cutoff_date = datetime.now() - timedelta(days=days)
        initial_count = len(df)
        df = df[df['timestamp'] >= cutoff_date]
        filtered_count = initial_count - len(df)
        
        if filtered_count > 0:
            print(f"📅 {filtered_count} lignes filtrées (avant {cutoff_date.date()})")
        
        # Garder uniquement les colonnes standardisées qui existent
        standard_cols = ['timestamp', 'machine_id', 'temperature', 'pressure', 'vibration']
        available_cols = [col for col in standard_cols if col in df.columns]
        
        df = df[available_cols]
        
        print(f"🎯 Extraction réussie: {len(df)} lignes")
        print(f"   Colonnes finales: {available_cols}")
        
        if not df.empty:
            print(f"   Période: {df['timestamp'].min().date()} au {df['timestamp'].max().date()}")
        
        return df
        
    except FileNotFoundError:
        print(f"❌ ERREUR: Fichier non trouvé: {file_path}")
        return pd.DataFrame()
    except pd.errors.EmptyDataError:
        print(f"❌ ERREUR: Fichier vide: {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"❌ ERREUR inattendue: {type(e).__name__}: {e}")
        return pd.DataFrame()

def extract_quality_data(file_path="data/raw/quality_data.csv"):
    """
    Extrait les données de contrôle qualité selon Task 1.2
    Chemin par défaut: data/raw/quality_data.csv
    
    Args:
        file_path (str): Chemin vers le fichier CSV de qualité
    
    Returns:
        pandas.DataFrame: DataFrame avec résultats des contrôles qualité
    """
    try:
        # Chemin absolu pour débogage
        abs_path = os.path.abspath(file_path)
        print(f"📁 Extraction qualité depuis: {file_path}")
        print(f"   Chemin absolu: {abs_path}")
        
        # Vérifier si le fichier existe
        if not os.path.exists(file_path):
            print(f"❌ ERREUR: Fichier '{file_path}' non trouvé!")
            print(f"   Vérifiez que le fichier existe dans: data/raw/")
            return pd.DataFrame()
        
        # Essayer différents encodages
        encodings = ['utf-8', 'ISO-8859-1', 'latin-1', 'windows-1252', 'cp1252']
        df = None
        used_encoding = None
        
        for encoding in encodings:
            try:
                df = pd.read_csv(file_path, encoding=encoding, on_bad_lines='skip')
                used_encoding = encoding
                print(f"✅ Encodage réussi: {encoding}")
                break
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"⚠️ Erreur avec {encoding}: {e}")
                continue
        
        if df is None:
            # Dernier essai sans spécifier d'encodage
            try:
                df = pd.read_csv(file_path, on_bad_lines='skip')
                used_encoding = 'auto'
                print(f"✅ Lecture sans encodage spécifié")
            except Exception as e:
                print(f"❌ Échec total de lecture: {e}")
                return pd.DataFrame()
        
        print(f"📊 Fichier lu: {len(df)} lignes, {len(df.columns)} colonnes")
        print(f"📋 Colonnes originales ({len(df.columns)}):")
        for i, col in enumerate(df.columns):
            print(f"   {i+1:2d}. '{col}'")
        
        # Normaliser les noms de colonnes
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        
        # Filtrer uniquement les inspections complétées (si colonne 'status' existe)
        if 'status' in df.columns:
            initial_count = len(df)
            # Convertir en string et minuscules pour la comparaison
            df['status'] = df['status'].astype(str).str.lower().str.strip()
            
            # Chercher différentes formes de "completed"
            completed_vals = ['completed', 'complete', 'done', 'finished', 'ok', 'success']
            mask = df['status'].isin(completed_vals)
            
            if mask.any():
                df = df[mask]
                filtered_count = initial_count - len(df)
                if filtered_count > 0:
                    print(f"🔍 {filtered_count} inspections filtrées (statut non complet)")
            else:
                print(f"⚠️ Aucune inspection avec statut 'completed' trouvée")
                print(f"   Valeurs de statut uniques: {df['status'].unique()[:5]}")
        
        # Chercher les colonnes importantes
        important_cols = ['timestamp', 'time', 'machine_id', 'machine', 'result', 
                         'defect', 'defect_type', 'inspection_result']
        
        found_cols = [col for col in important_cols if col in df.columns]
        if found_cols:
            print(f"🔑 Colonnes importantes trouvées: {found_cols}")
        
        print(f"🎯 Extraction qualité réussie: {len(df)} lignes")
        
        if not df.empty and 'timestamp' in df.columns:
            try:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                print(f"   Période: {df['timestamp'].min().date()} au {df['timestamp'].max().date()}")
            except:
                pass
        
        return df
        
    except FileNotFoundError:
        print(f"❌ ERREUR: Fichier non trouvé: {file_path}")
        return pd.DataFrame()
    except pd.errors.EmptyDataError:
        print(f"❌ ERREUR: Fichier vide: {file_path}")
        return pd.DataFrame()
    except Exception as e:
        print(f"❌ ERREUR inattendue: {type(e).__name__}: {e}")
        return pd.DataFrame()

# ============================================================================
# TEST AUTOMATIQUE - S'exécute SEULEMENT si on lance extract.py directement
# ============================================================================
if __name__ == "__main__":
    print("=" * 70)
    print("TEST AUTOMATIQUE DE L'EXTRACTION")
    print("=" * 70)
    
    # Chemins fixes selon la structure du projet
    SENSOR_PATH = "data/raw/sensor_data.csv"
    QUALITY_PATH = "data/raw/quality_data.csv"
    
    print(f"\n📍 CHEMINS CONFIGURÉS:")
    print(f"   Capteurs:  {SENSOR_PATH}")
    print(f"   Qualité:   {QUALITY_PATH}")
    
    # Créer les dossiers s'ils n'existent pas
    os.makedirs("data/raw", exist_ok=True)
    
    # Test 1: Extraction capteurs
    print(f"\n{'='*35} CAPTEURS {'='*35}")
    sensor_df = extract_sensor_data(SENSOR_PATH)
    
    if not sensor_df.empty:
        print(f"\n✅ TEST CAPTEURS RÉUSSI!")
        print(f"   Shape: {sensor_df.shape}")
        print(f"   Colonnes: {list(sensor_df.columns)}")
        print(f"\n   Aperçu (3 premières lignes):")
        print(sensor_df.head(3))
        print(f"\n   Info types:")
        print(sensor_df.dtypes)
    else:
        print(f"\n❌ TEST CAPTEURS ÉCHOUÉ - Création de données de test...")
        
        # Créer des données de test (CORRIGÉ: 'h' au lieu de 'H')
        test_dates = pd.date_range('2024-01-01', periods=100, freq='h')  # 'h' minuscule
        test_data = pd.DataFrame({
            'timestamp': test_dates,
            'machine_id': ['M1', 'M2'] * 50,
            'temperature': np.random.normal(70, 10, 100),
            'pressure': np.random.normal(5, 1, 100),
            'vibration': np.random.normal(30, 5, 100)
        })
        test_data.to_csv(SENSOR_PATH, index=False)
        print(f"   ✅ Données test créées: {SENSOR_PATH}")
        
        # Réessayer l'extraction
        sensor_df = extract_sensor_data(SENSOR_PATH)
    
    # Test 2: Extraction qualité
    print(f"\n{'='*35} QUALITÉ {'='*35}")
    quality_df = extract_quality_data(QUALITY_PATH)
    
    if not quality_df.empty:
        print(f"\n✅ TEST QUALITÉ RÉUSSI!")
        print(f"   Shape: {quality_df.shape}")
        print(f"   Colonnes: {list(quality_df.columns)}")
        print(f"\n   Aperçu (3 premières lignes):")
        print(quality_df.head(3))
    else:
        print(f"\n❌ TEST QUALITÉ ÉCHOUÉ - Création de données de test...")
        
        # Créer des données de test qualité (CORRIGÉ: 'h' au lieu de 'H')
        test_dates = pd.date_range('2024-01-01', periods=50, freq='2h')  # 'h' minuscule
        test_quality = pd.DataFrame({
            'timestamp': test_dates,
            'machine_id': np.random.choice(['M1', 'M2', 'M3'], 50),
            'result': np.random.choice(['pass', 'fail'], 50, p=[0.9, 0.1]),
            'defect_type': np.random.choice(['none', 'crack', 'deformation'], 50),
            'status': ['completed'] * 50
        })
        test_quality.to_csv(QUALITY_PATH, index=False, encoding='utf-8')
        print(f"   ✅ Données test créées: {QUALITY_PATH}")
        
        # Réessayer l'extraction
        quality_df = extract_quality_data(QUALITY_PATH)
    
    # Résumé final
    print(f"\n{'='*70}")
    print("RÉSUMÉ FINAL DU TEST:")
    print(f"{'='*70}")
    print(f"📍 Capteurs: {'✅ SUCCÈS' if not sensor_df.empty else '❌ ÉCHEC'}")
    if not sensor_df.empty:
        print(f"   - Lignes: {len(sensor_df)}")
        print(f"   - Colonnes: {list(sensor_df.columns)}")
        print(f"   - Période: {sensor_df['timestamp'].min().date()} à {sensor_df['timestamp'].max().date()}")
    
    print(f"\n📍 Qualité: {'✅ SUCCÈS' if not quality_df.empty else '❌ ÉCHEC'}")
    if not quality_df.empty:
        print(f"   - Lignes: {len(quality_df)}")
        print(f"   - Colonnes: {list(quality_df.columns)}")
        if 'timestamp' in quality_df.columns:
            try:
                quality_df['timestamp'] = pd.to_datetime(quality_df['timestamp'])
                print(f"   - Période: {quality_df['timestamp'].min().date()} à {quality_df['timestamp'].max().date()}")
            except:
                pass
    
    print(f"\n🎉 Phase 1 (EXTRACT) terminée avec succès!")
