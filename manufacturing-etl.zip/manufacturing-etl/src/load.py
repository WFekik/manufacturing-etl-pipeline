import sqlite3
import pandas as pd
import os

def create_database_schema(db_path="database/production.db"):
    """
    Task 3.1: Design Database Schema
    Task 3.2: Create Database Connection
    """
    print(f"🗄️  Création du schéma de base de données: {db_path}")
    
    # Créer le dossier s'il n'existe pas
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Table 1: sensor_readings (EXACTEMENT comme Task 3.1)
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS sensor_readings (
            record_id TEXT PRIMARY KEY,
            timestamp DATETIME,
            line_id TEXT,
            machine_id TEXT,
            temperature REAL,
            pressure REAL,
            vibration REAL,
            power REAL,
            data_quality TEXT
        )
        ''')
        print("✅ Table 'sensor_readings' créée")
        
        # Table 2: quality_checks (EXACTEMENT comme Task 3.1)
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS quality_checks (
            check_id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME,
            line_id TEXT,
            machine_id TEXT,
            result TEXT,
            defect_type TEXT
        )
        ''')
        print("✅ Table 'quality_checks' créée")
        
        # Table 3: hourly_summary (EXACTEMENT comme Task 3.1)
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS hourly_summary (
            summary_id INTEGER PRIMARY KEY AUTOINCREMENT,
            hour DATETIME,
            line_id TEXT,
            machine_id TEXT,
            avg_temperature REAL,
            min_temperature REAL,
            max_temperature REAL,
            avg_pressure REAL,
            avg_vibration REAL,
            total_checks INTEGER,
            defect_count INTEGER,
            defect_rate REAL
        )
        ''')
        print("✅ Table 'hourly_summary' créée")
        
        conn.commit()
        print(f"🎉 Schéma de base créé avec succès: {db_path}")
        
    except Exception as e:
        print(f"❌ Erreur création schéma: {e}")
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()

def load_to_database(sensor_df, quality_df, summary_df, db_path="database/production.db"):
    """
    Task 3.3: Load Data to Database
    """
    print(f"\n💾 Chargement des données dans la base: {db_path}")
    
    # Vérifier que le schéma existe
    if not os.path.exists(db_path):
        print("⚠️ Base de données non trouvée, création du schéma...")
        create_database_schema(db_path)
    
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # ========== CHARGEMENT SENSOR_READINGS ==========
        if not sensor_df.empty:
            print(f"\n📊 Chargement sensor_readings...")
            
            for _, row in sensor_df.iterrows():
                # Préparer les valeurs selon le schéma exact
                record_id = row.get('record_id', None)
                timestamp = pd.to_datetime(row.get('timestamp', None)).strftime('%Y-%m-%d %H:%M:%S') if pd.notna(row.get('timestamp', None)) else None
                line_id = row.get('line_id', None)
                machine_id = row.get('machine_id', None)
                temperature = float(row.get('temperature', 0)) if pd.notna(row.get('temperature', None)) else None
                pressure = float(row.get('pressure', 0)) if pd.notna(row.get('pressure', None)) else None
                vibration = float(row.get('vibration', 0)) if pd.notna(row.get('vibration', None)) else None
                power = float(row.get('power', 0)) if pd.notna(row.get('power', None)) else None
                data_quality = row.get('data_quality', 'unknown')
                
                cursor.execute('''
                INSERT OR REPLACE INTO sensor_readings 
                (record_id, timestamp, line_id, machine_id, temperature, 
                 pressure, vibration, power, data_quality)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (record_id, timestamp, line_id, machine_id, 
                      temperature, pressure, vibration, power, data_quality))
            
            print(f"✅ {len(sensor_df)} lignes chargées dans sensor_readings")
        
        else:
            print("⚠️ Aucune donnée capteur à charger")
        
        # ========== CHARGEMENT QUALITY_CHECKS ==========
        if not quality_df.empty:
            print(f"\n📊 Chargement quality_checks...")
            
            for _, row in quality_df.iterrows():
                timestamp = pd.to_datetime(row.get('timestamp', None)).strftime('%Y-%m-%d %H:%M:%S') if pd.notna(row.get('timestamp', None)) else None
                line_id = row.get('line_id', None)
                machine_id = row.get('machine_id', None)
                result = row.get('result', None)
                defect_type = row.get('defect_type', None)
                
                cursor.execute('''
                INSERT OR REPLACE INTO quality_checks 
                (timestamp, line_id, machine_id, result, defect_type)
                VALUES (?, ?, ?, ?, ?)
                ''', (timestamp, line_id, machine_id, result, defect_type))
            
            print(f"✅ {len(quality_df)} lignes chargées dans quality_checks")
        
        else:
            print("⚠️ Aucune donnée qualité à charger")
        
        # ========== CHARGEMENT HOURLY_SUMMARY ==========
        if not summary_df.empty:
            print(f"\n📊 Chargement hourly_summary...")
            
            for _, row in summary_df.iterrows():
                hour = pd.to_datetime(row.get('hour', None)).strftime('%Y-%m-%d %H:00:00') if pd.notna(row.get('hour', None)) else None
                line_id = row.get('line_id', None)
                machine_id = row.get('machine_id', None)
                avg_temperature = float(row.get('avg_temperature', 0)) if pd.notna(row.get('avg_temperature', None)) else None
                min_temperature = float(row.get('min_temperature', 0)) if pd.notna(row.get('min_temperature', None)) else None
                max_temperature = float(row.get('max_temperature', 0)) if pd.notna(row.get('max_temperature', None)) else None
                avg_pressure = float(row.get('avg_pressure', 0)) if pd.notna(row.get('avg_pressure', None)) else None
                avg_vibration = float(row.get('avg_vibration', 0)) if pd.notna(row.get('avg_vibration', None)) else None
                total_checks = int(row.get('total_checks', 0))
                defect_count = int(row.get('defect_count', 0))
                defect_rate = float(row.get('defect_rate', 0))
                
                cursor.execute('''
                INSERT OR REPLACE INTO hourly_summary 
                (hour, line_id, machine_id, avg_temperature, min_temperature, 
                 max_temperature, avg_pressure, avg_vibration, total_checks, 
                 defect_count, defect_rate)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (hour, line_id, machine_id, avg_temperature, min_temperature,
                      max_temperature, avg_pressure, avg_vibration, total_checks,
                      defect_count, defect_rate))
            
            print(f"✅ {len(summary_df)} lignes chargées dans hourly_summary")
        
        else:
            print("⚠️ Aucune agrégation horaire à charger")
        
        conn.commit()
        
        # ========== VÉRIFICATION ==========
        print(f"\n📋 Vérification finale:")
        for table in ['sensor_readings', 'quality_checks', 'hourly_summary']:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            print(f"   {table}: {count} lignes")
        
        print(f"\n🎉 Task 3.3 terminé: Base de données 'production.db' peuplée!")
        
    except Exception as e:
        print(f"❌ Erreur lors du chargement: {e}")
        import traceback
        traceback.print_exc()
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()

def test_queries(db_path="database/production.db"):
    """
    Teste les requêtes SQL selon les spécifications du projet
    """
    print(f"\n🔍 TEST DES REQUÊTES SQL: {db_path}")
    
    if not os.path.exists(db_path):
        print("❌ Base de données non trouvée!")
        return
    
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        
        print(f"\n📊 REQUÊTES DE TEST (selon spécifications):")
        print("=" * 60)
        
        queries = [
            # 1. Check total records loaded
            ("SELECT COUNT(*) FROM sensor_readings", 
             "Check total records loaded"),
            
            # 2. View hourly summary for a specific line
            ("""SELECT * FROM hourly_summary 
                WHERE line_id LIKE '%1%' 
                ORDER BY hour DESC 
                LIMIT 10""",
             "View hourly summary for a specific line"),
            
            # 3. Find high defect rate hours
            ("""SELECT hour, line_id, machine_id, defect_rate
                FROM hourly_summary 
                WHERE defect_rate > 5.0 
                ORDER BY defect_rate DESC""",
             "Find high defect rate hours"),
            
            # 4. Check data quality distribution
            ("""SELECT data_quality, COUNT(*) as count
                FROM sensor_readings 
                GROUP BY data_quality""",
             "Check data quality distribution"),
            
            # 5. Join sensor data with quality checks
            ("""SELECT s.timestamp, s.machine_id, s.temperature, q.result as quality_result
                FROM sensor_readings s
                LEFT JOIN quality_checks q
                ON s.machine_id = q.machine_id AND s.timestamp = q.timestamp
                LIMIT 10""",
             "Join sensor data with quality checks"),
            
            # 6. Average temperature by machine
            ("""SELECT machine_id, 
                       AVG(temperature) as avg_temp, 
                       MIN(temperature) as min_temp, 
                       MAX(temperature) as max_temp
                FROM sensor_readings 
                GROUP BY machine_id""",
             "Average temperature by machine")
        ]
        
        for query, description in queries:
            print(f"\n{description}:")
            print(f"SQL: {query[:80]}..." if len(query) > 80 else f"SQL: {query}")
            
            try:
                result = pd.read_sql_query(query, conn)
                print(f"Résultat ({len(result)} lignes):")
                if not result.empty:
                    print(result.to_string(index=False))
                else:
                    print("   (Aucun résultat)")
            except Exception as e:
                print(f"❌ Erreur: {e}")
        
        print(f"\n{'='*60}")
        print("✅ Toutes les requêtes de test exécutées avec succès!")
        
    except Exception as e:
        print(f"❌ Erreur: {e}")
    finally:
        if conn:
            conn.close()


# ============================================================================
# TEST AUTOMATIQUE
# ============================================================================
if __name__ == "__main__":
    print("=" * 70)
    print("TEST DE LA PHASE 3: LOAD")
    print("=" * 70)
    
    # Importer les fonctions de transformation
    try:
        from transform import clean_sensor_data, standardize_data, join_sensor_quality, calculate_hourly_summaries
    except ImportError:
        print("❌ Impossible d'importer transform.py")
        print("   Assurez-vous qu'il est dans le même dossier ou ajoutez-le au path")
        exit()
    
    # Créer des données de test
    print("\n📝 Création de données de test...")
    
    import numpy as np
    
    # Données capteurs
    sensor_test = pd.DataFrame({
        'Timestamp': pd.date_range('2024-01-01', periods=20, freq='h'),
        'Machine ID': ['M1', 'M2'] * 10,
        'Line ID': ['L1', 'L2'] * 10,
        'temperature': np.random.normal(70, 5, 20),
        'pressure': np.random.normal(5, 0.5, 20),
        'vibration': np.random.normal(30, 3, 20),
        'power': np.random.normal(100, 10, 20)
    })
    
    # Données qualité
    quality_test = pd.DataFrame({
        'timestamp': pd.date_range('2024-01-01', periods=10, freq='2h'),
        'machine_id': ['M1', 'M2'] * 5,
        'line_id': ['L1', 'L2'] * 5,
        'result': ['pass'] * 8 + ['fail'] * 2,
        'defect_type': ['none'] * 8 + ['crack'] * 2
    })
    
    print(f"✅ Données test créées")
    print(f"   Capteurs: {sensor_test.shape}")
    print(f"   Qualité: {quality_test.shape}")
    
    # Appliquer les transformations
    print("\n🔄 Application des transformations...")
    
    sensor_clean = clean_sensor_data(sensor_test)
    sensor_std = standardize_data(sensor_clean)
    quality_std = standardize_data(quality_test)
    merged = join_sensor_quality(sensor_std, quality_std)
    hourly = calculate_hourly_summaries(merged)
    
    print(f"\n📊 Données prêtes pour le chargement:")
    print(f"   sensor_readings: {sensor_std.shape}")
    print(f"   quality_checks: {quality_std.shape}")
    print(f"   hourly_summary: {hourly.shape}")
    
    # Test 1: Création du schéma
    print(f"\n{'='*35} TEST 3.1: SCHÉMA {'='*35}")
    create_database_schema()
    
    # Test 2: Chargement des données
    print(f"\n{'='*35} TEST 3.3: CHARGEMENT {'='*35}")
    load_to_database(sensor_std, quality_std, hourly)
    
    # Test 3: Vérification
    print(f"\n{'='*35} TEST: REQUÊTES {'='*35}")
    test_queries()
    
    print(f"\n{'='*70}")
    print("🎉 PHASE 3 (LOAD) COMPLÈTEMENT IMPLÉMENTÉE!")
    print("✅ Task 3.1: Schema créé")
    print("✅ Task 3.2: Connection 'production.db' établie")
    print("✅ Task 3.3: Données chargées dans les 3 tables")
    print("=" * 70)
