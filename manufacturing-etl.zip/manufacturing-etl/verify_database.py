import sqlite3
import pandas as pd

print("Vérification de production.db...")
print("=" * 50)

conn = sqlite3.connect("database/production.db")

# 1. Liste des tables
tables = pd.read_sql_query("SELECT name FROM sqlite_master WHERE type='table'", conn)
print("Tables disponibles:")
print(tables)

# 2. Nombre de lignes par table
print("\nNombre de lignes:")
for table in ['sensor_readings', 'quality_checks', 'hourly_summary']:
    count = pd.read_sql_query(f"SELECT COUNT(*) as count FROM {table}", conn)
    print(f"  {table}: {count.iloc[0,0]} lignes")

# 3. Aperçu des données
print("\nAperçu sensor_readings:")
print(pd.read_sql_query("SELECT * FROM sensor_readings LIMIT 3", conn))

print("\nAperçu quality_checks:")
print(pd.read_sql_query("SELECT * FROM quality_checks LIMIT 3", conn))

print("\nAperçu hourly_summary:")
print(pd.read_sql_query("SELECT * FROM hourly_summary LIMIT 3", conn))

conn.close()

print("\n" + "=" * 50)
print("✅ Vérification terminée!")
