"""
Manufacturing ETL Pipeline
Production Line Data Integration
Author: [Votre Nom]
Date: [Date]
"""

import sys
import os
from datetime import datetime

# Ajouter le dossier src au path Python
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

# Importer toutes les fonctions nécessaires
from extract import extract_sensor_data, extract_quality_data
from transform import clean_sensor_data, standardize_data, join_sensor_quality, calculate_hourly_summaries
from load import create_database_schema, load_to_database, test_queries

def display_header():
    """Affiche l'en-tête du programme"""
    print("=" * 70)
    print("MANUFACTURING ETL PIPELINE")
    print("Production Line Data Integration")
    print("=" * 70)
    print(f"Démarrage: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)

def create_test_data_if_needed():
    """Crée des données de test si les fichiers CSV n'existent pas"""
    print("\n📁 Vérification des fichiers de données...")
    
    sensor_path = "data/raw/sensor_data.csv"
    quality_path = "data/raw/quality_data.csv"
    
    files_exist = os.path.exists(sensor_path) and os.path.exists(quality_path)
    
    if not files_exist:
        print("⚠️ Fichiers CSV non trouvés dans data/raw/")
        print("   Création de données de test...")
        
        try:
            # Importer pour créer des données
            import pandas as pd
            import numpy as np
            
            # Créer sensor_data.csv
            dates = pd.date_range('2024-01-01', periods=100, freq='h')
            sensor_data = pd.DataFrame({
                'timestamp': dates,
                'machine_id': ['M1', 'M2'] * 50,
                'line_id': ['Line_1', 'Line_2'] * 50,
                'temperature': np.random.normal(70, 10, 100),
                'pressure': np.random.normal(5, 1, 100),
                'vibration': np.random.normal(30, 5, 100),
                'power': np.random.normal(100, 20, 100)
            })
            sensor_data.to_csv(sensor_path, index=False)
            print(f"✅ {sensor_path} créé ({len(sensor_data)} lignes)")
            
            # Créer quality_data.csv
            dates = pd.date_range('2024-01-01', periods=50, freq='2h')
            quality_data = pd.DataFrame({
                'timestamp': dates,
                'machine_id': np.random.choice(['M1', 'M2'], 50),
                'line_id': np.random.choice(['Line_1', 'Line_2'], 50),
                'result': np.random.choice(['pass', 'fail'], 50, p=[0.9, 0.1]),
                'defect_type': np.random.choice(['none', 'crack', 'deformation'], 50),
                'status': ['completed'] * 50
            })
            quality_data.to_csv(quality_path, index=False, encoding='utf-8')
            print(f"✅ {quality_path} créé ({len(quality_data)} lignes)")
            
            return True
            
        except Exception as e:
            print(f"❌ Erreur création données test: {e}")
            return False
    else:
        print("✅ Fichiers CSV trouvés dans data/raw/")
        return True

def phase_extract():
    """Exécute la phase 1: EXTRACT"""
    print(f"\n📥 PHASE 1: EXTRACTION")
    print("-" * 40)
    
    # Chemins des fichiers
    sensor_path = "data/raw/sensor_data.csv"
    quality_path = "data/raw/quality_data.csv"
    
    print(f"Capteurs: {sensor_path}")
    sensor_raw = extract_sensor_data(sensor_path, days=7)
    
    print(f"\nQualité: {quality_path}")
    quality_raw = extract_quality_data(quality_path)
    
    # Vérification
    if sensor_raw.empty:
        print("\n❌ ERREUR: Aucune donnée capteur extraite!")
        return None, None
    
    if quality_raw.empty:
        print("\n⚠️ AVERTISSEMENT: Aucune donnée qualité extraite")
        print("   Le pipeline continuera avec des données qualité vides")
    
    # Sauvegarder les données brutes
    os.makedirs("data/processed", exist_ok=True)
    sensor_raw.to_csv("data/processed/sensor_raw.csv", index=False)
    quality_raw.to_csv("data/processed/quality_raw.csv", index=False)
    
    print(f"\n✅ Extraction terminée:")
    print(f"   Capteurs: {len(sensor_raw)} lignes")
    print(f"   Qualité: {len(quality_raw)} lignes")
    
    return sensor_raw, quality_raw

def phase_transform(sensor_raw, quality_raw):
    """Exécute la phase 2: TRANSFORM"""
    print(f"\n🔄 PHASE 2: TRANSFORMATION")
    print("-" * 40)
    
    # Task 2.1: Clean Sensor Data
    print("1. Nettoyage des données capteurs...")
    sensor_clean = clean_sensor_data(sensor_raw)
    
    # Task 2.2: Standardize Data
    print("\n2. Standardisation des données...")
    sensor_std = standardize_data(sensor_clean)
    quality_std = standardize_data(quality_raw)
    
    # Task 2.3: Join Sensor and Quality Data
    print("\n3. Jointure des données capteurs et qualité...")
    merged_data = join_sensor_quality(sensor_std, quality_std)
    
    # Task 2.4: Calculate Hourly Summaries
    print("\n4. Calcul des agrégations horaires...")
    hourly_summaries = calculate_hourly_summaries(merged_data)
    
    # Sauvegarder les données transformées
    sensor_std.to_csv("data/processed/sensor_clean.csv", index=False)
    quality_std.to_csv("data/processed/quality_clean.csv", index=False)
    merged_data.to_csv("data/processed/merged_data.csv", index=False)
    hourly_summaries.to_csv("data/processed/hourly_summaries.csv", index=False)
    
    print(f"\n✅ Transformation terminée:")
    print(f"   Capteurs nettoyés: {len(sensor_std)} lignes")
    print(f"   Qualité standardisée: {len(quality_std)} lignes")
    print(f"   Données jointes: {len(merged_data)} lignes")
    print(f"   Agrégations horaires: {len(hourly_summaries)} lignes")
    
    return sensor_std, quality_std, hourly_summaries

def phase_load(sensor_std, quality_std, hourly_summaries):
    """Exécute la phase 3: LOAD"""
    print(f"\n💾 PHASE 3: CHARGEMENT")
    print("-" * 40)
    
    # Task 3.1 & 3.2: Create Database Schema and Connection
    print("1. Création du schéma de base de données...")
    create_database_schema()
    
    # Task 3.3: Load Data to Database
    print("\n2. Chargement des données dans la base...")
    load_to_database(sensor_std, quality_std, hourly_summaries)
    
    print(f"\n✅ Chargement terminé")
    return True

def phase_test():
    """Exécute les tests de vérification"""
    print(f"\n🧪 PHASE 4: VÉRIFICATION")
    print("-" * 40)
    
    print("Exécution des requêtes de test...")
    test_queries()
    
    print(f"\n✅ Vérification terminée")

def display_summary():
    """Affiche le résumé final"""
    print(f"\n{'='*70}")
    print("🎉 PIPELINE ETL TERMINÉ AVEC SUCCÈS!")
    print(f"Fin: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    print(f"\n📁 FICHIERS CRÉÉS:")
    print(f"   1. database/production.db")
    print(f"      - sensor_readings: Données détaillées des capteurs")
    print(f"      - quality_checks:  Résultats des inspections qualité")
    print(f"      - hourly_summary:  Agrégations horaires")
    
    print(f"\n   2. data/processed/")
    print(f"      - sensor_raw.csv:      Données capteurs brutes")
    print(f"      - quality_raw.csv:     Données qualité brutes")
    print(f"      - sensor_clean.csv:    Données capteurs nettoyées")
    print(f"      - quality_clean.csv:   Données qualité nettoyées")
    print(f"      - merged_data.csv:     Données jointes")
    print(f"      - hourly_summaries.csv: Agrégations horaires")
    
    print(f"\n🔍 POUR TESTER MANUELLEMENT:")
    print(f"   sqlite3 database/production.db")
    print(f"   .tables")
    print(f"   SELECT COUNT(*) FROM sensor_readings;")
    print(f"   SELECT * FROM hourly_summary LIMIT 5;")
    
    print(f"\n📊 REQUÊTES PRÉDÉFINIES DISPONIBLES:")
    print(f"   1. Total records in sensor_readings")
    print(f"   2. Hourly summary for a specific line")
    print(f"   3. High defect rate hours")
    print(f"   4. Data quality distribution")
    print(f"   5. Join sensor data with quality checks")
    print(f"   6. Average temperature by machine")
    
    print("=" * 70)

def main():
    """Fonction principale du pipeline ETL"""
    
    # Afficher l'en-tête
    display_header()
    
    # Créer les dossiers nécessaires
    os.makedirs("data/raw", exist_ok=True)
    os.makedirs("data/processed", exist_ok=True)
    os.makedirs("database", exist_ok=True)
    
    # Vérifier/créer les données de test
    if not create_test_data_if_needed():
        print("❌ Impossible de créer les données de test")
        return
    
    try:
        # === PHASE 1: EXTRACT ===
        sensor_raw, quality_raw = phase_extract()
        if sensor_raw is None:
            return
        
        # === PHASE 2: TRANSFORM ===
        sensor_std, quality_std, hourly_summaries = phase_transform(sensor_raw, quality_raw)
        
        # === PHASE 3: LOAD ===
        if not phase_load(sensor_std, quality_std, hourly_summaries):
            return
        
        # === PHASE 4: TEST ===
        phase_test()
        
        # === RÉSUMÉ FINAL ===
        display_summary()
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Pipeline interrompu par l'utilisateur")
        print("Arrêt en cours...")
        return
        
    except Exception as e:
        print(f"\n❌ ERREUR CRITIQUE: {e}")
        import traceback
        traceback.print_exc()
        print("\nLe pipeline s'est arrêté à cause d'une erreur.")

def run_quick_test():
    """Exécute un test rapide du pipeline"""
    print("\n🔧 MODE TEST RAPIDE")
    print("Exécution d'un test avec des données minimales...")
    
    # Créer des données de test minimales
    import pandas as pd
    import numpy as np
    
    # Données de test minimales
    test_sensor = pd.DataFrame({
        'timestamp': pd.date_range('2024-01-01', periods=10, freq='h'),
        'machine_id': ['M1', 'M2'] * 5,
        'temperature': np.random.normal(70, 5, 10),
        'pressure': np.random.normal(5, 0.5, 10),
        'vibration': np.random.normal(30, 3, 10)
    })
    
    test_quality = pd.DataFrame({
        'timestamp': pd.date_range('2024-01-01', periods=5, freq='2h'),
        'machine_id': ['M1', 'M2', 'M1', 'M2', 'M1'],
        'result': ['pass', 'fail', 'pass', 'pass', 'fail']
    })
    
    # Sauvegarder
    test_sensor.to_csv("data/raw/sensor_data.csv", index=False)
    test_quality.to_csv("data/raw/quality_data.csv", index=False)
    
    print("✅ Données de test créées")
    print("Exécution du pipeline...")
    
    # Exécuter le pipeline
    main()

if __name__ == "__main__":
    # Vérifier les arguments de ligne de commande
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        run_quick_test()
    elif len(sys.argv) > 1 and sys.argv[1] == "--help":
        print("Usage: python main.py [OPTION]")
        print("\nOptions:")
        print("  --test     Exécute un test rapide avec des données minimales")
        print("  --help     Affiche ce message d'aide")
        print("\nSans option: Exécute le pipeline complet")
    else:
        # Exécuter le pipeline complet
        main()
